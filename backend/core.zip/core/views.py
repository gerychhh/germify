from django.shortcuts import render, redirect
import datetime
from .models import Post
from django.contrib.auth import login
from django.shortcuts import render, redirect
from .forms import RegisterForm


# ВРЕМЕННОЕ "хранилище" постов в памяти
POSTS = [
    {
        "author": "Система",
        "text": "Добро пожаловать в Germify! Это тестовый пост.",
        "created_at": datetime.datetime.now(),
    }
]



def feed(request):
    posts = Post.objects.all()  # теперь из БД
    return render(request, "core/feed.html", {"posts": posts})

def create_post(request):
    if request.method == "POST":
        text = request.POST.get("text", "").strip()
        if text:
            Post.objects.create(
                author_name="Аноним",  # позже заменим на текущего юзера
                text=text,
            )
        return redirect("feed")


def messages_view(request):
    return render(request, "core/messages.html")


def communities_view(request):
    return render(request, "core/communities.html")


def profile_view(request):
    return render(request, "core/profile.html")

def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data["password"])
            user.save()
            login(request, user)
            return redirect("feed")
    else:
        form = RegisterForm()

    return render(request, "core/register.html", {"form": form})