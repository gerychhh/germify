from django.urls import path
from django.contrib.auth import views as auth_views
from .views import register_view
from django.urls import path
from .views import (
    feed,
    create_post,
    messages_view,
    communities_view,
    profile_view,
)

urlpatterns = [
    path("", feed, name="feed"),  # корень приложения core -> лента
    path("create-post/", create_post, name="create_post"),
    path("messages/", messages_view, name="messages"),
    path("communities/", communities_view, name="communities"),
    path("profile/", profile_view, name="profile"),
]
urlpatterns = [
    path("register/", register_view, name="register"),
    path("login/", auth_views.LoginView.as_view(template_name="core/login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
]